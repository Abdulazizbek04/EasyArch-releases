@echo off
REM Easy_arch — tez o'rnatish (sinov uchun). Revitni yoping, so'ng shu faylni ishga tushiring.
setlocal
set "ADDINS=%APPDATA%\Autodesk\Revit\Addins"
for %%V in (2025 2026 2027) do (
    if exist "%~dp0%%V\EasyArch.dll" (
        if not exist "%ADDINS%\%%V\EasyArch" mkdir "%ADDINS%\%%V\EasyArch"
        copy /Y "%~dp0%%V\EasyArch*.dll" "%ADDINS%\%%V\EasyArch\" >nul
        copy /Y "%~dp0%%V\EasyArch.addin" "%ADDINS%\%%V\" >nul
        echo Revit %%V: o'rnatildi
    )
)
echo.
echo Tayyor. Revitni oching - "Easy_arch" tabi paydo bo'ladi.
pause
