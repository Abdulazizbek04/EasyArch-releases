@echo off
REM Easy_arch — o'chirish. Revitni yoping, so'ng shu faylni ishga tushiring.
setlocal
set "ADDINS=%APPDATA%\Autodesk\Revit\Addins"
for %%V in (2025 2026 2027) do (
    if exist "%ADDINS%\%%V\EasyArch.addin" del /Q "%ADDINS%\%%V\EasyArch.addin"
    if exist "%ADDINS%\%%V\EasyArch" rmdir /S /Q "%ADDINS%\%%V\EasyArch"
)
echo Easy_arch o'chirildi.
pause
